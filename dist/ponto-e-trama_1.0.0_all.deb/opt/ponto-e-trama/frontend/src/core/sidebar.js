const BarraLateral = (() => {
function alternarFerramenta(botaoClicado) {
const botoesFerramenta = document.querySelectorAll(".barraLateral .botaoFerramenta");
const todasSecoesFerramentas = document.querySelectorAll(".secao-ferramenta");
const secaoContador = document.getElementById("secao-contador-carreiras");
const conteinerContador = document.getElementById("conteiner-contador");
const ferramenta = botaoClicado.dataset.ferramenta || (botaoClicado.getAttribute("title") || "").toLowerCase();
const isContador = ferramenta === "contador-carreiras" || ferramenta.includes("contador");
botoesFerramenta.forEach((b) => b.classList.remove("ativo"));
botaoClicado.classList.add("ativo");
todasSecoesFerramentas.forEach((secao) => {
secao.style.display = "none";
});
if (!isContador) {
if (secaoContador) secaoContador.style.display = "none";
if (conteinerContador) conteinerContador.style.display = "none";
}
const secaoAlvo = document.getElementById(`secao-${ferramenta}`);
if (secaoAlvo) {
secaoAlvo.style.display = "flex";
}
if (typeof PontoTramaApp !== "undefined" && typeof PontoTramaApp.garantirModulo === "function") {
PontoTramaApp.garantirModulo(ferramenta);
}
if (isContador) {
if (secaoContador) secaoContador.style.display = "flex";
if (conteinerContador) conteinerContador.style.display = "flex";
}
window.dispatchEvent(
new CustomEvent("ponto-trama:ferramenta-alterada", {
detail: { ferramenta }
})
);
const btnsMob = document.querySelectorAll("#nav-mobile-inferior .nav-mob-btn[data-mob-ferramenta]");
let achouNaBarra = false;
btnsMob.forEach((bm) => {
const ativo = bm.dataset.mobFerramenta === ferramenta;
bm.classList.toggle("ativo", ativo);
if (ativo) achouNaBarra = true;
});
const btnMais = document.getElementById("btn-nav-mob-mais");
if (btnMais) btnMais.classList.toggle("ativo", !achouNaBarra);
}
function init() {
const chkMenu = document.getElementById("opcao-menu");
const isMobileViewport = () =>
(typeof window !== "undefined" && window.innerWidth <= 768) ||
Boolean(typeof window !== "undefined" && window.PontoETramaAndroid);
if (chkMenu && isMobileViewport()) {
chkMenu.checked = true;
}
const botoesFerramenta = document.querySelectorAll(".barraLateral .botaoFerramenta");
botoesFerramenta.forEach((botao) => {
botao.addEventListener("click", () => {
alternarFerramenta(botao);
if (chkMenu && window.innerWidth <= 768) {
chkMenu.checked = true;
}
});
});
document.querySelectorAll("#nav-mobile-inferior .nav-mob-btn[data-mob-ferramenta]").forEach((btnMob) => {
btnMob.addEventListener("click", () => {
const alvo = btnMob.dataset.mobFerramenta;
const btnSide = document.querySelector(`.barraLateral .botaoFerramenta[data-ferramenta="${alvo}"]`);
if (btnSide) alternarFerramenta(btnSide);
if (chkMenu && window.innerWidth <= 768) {
chkMenu.checked = true;
}
});
});
const btnMobMais = document.getElementById("btn-nav-mob-mais");
if (btnMobMais && chkMenu) {
btnMobMais.addEventListener("click", (e) => {
e.stopPropagation();
chkMenu.checked = !chkMenu.checked;
});
}
const mainEl = document.querySelector("main");
if (mainEl && chkMenu) {
mainEl.addEventListener("click", () => {
if (window.innerWidth <= 768 && !chkMenu.checked) {
chkMenu.checked = true;
}
});
}
}
return {
init,
alternarFerramenta
};
})();
