const BarraLateral = (() => {
function alternarFerramenta(botaoClicado) {
const botoesFerramenta = document.querySelectorAll(".barraLateral .botaoFerramenta");
const todasSecoesFerramentas = document.querySelectorAll(".secao-ferramenta");
const secaoContador = document.getElementById("secao-contador-carreiras");
const conteinerContador = document.getElementById("conteiner-contador");
const ferramenta = botaoClicado.dataset.ferramenta || (botaoClicado.getAttribute("title") || "").toLowerCase();
const isContador = ferramenta === "contador-carreiras" || ferramenta.includes("contador");
botoesFerramenta.forEach((b) => b.classList.remove("ativo"));
botaoClicado.classList.add("ativo");
todasSecoesFerramentas.forEach((secao) => {
secao.style.display = "none";
});
if (!isContador) {
if (secaoContador) secaoContador.style.display = "none";
if (conteinerContador) conteinerContador.style.display = "none";
}
const secaoAlvo = document.getElementById(`secao-${ferramenta}`);
if (secaoAlvo) {
secaoAlvo.style.display = "flex";
}
if (typeof PontoTramaApp !== "undefined" && typeof PontoTramaApp.garantirModulo === "function") {
PontoTramaApp.garantirModulo(ferramenta);
}
if (isContador) {
if (secaoContador) secaoContador.style.display = "flex";
if (conteinerContador) conteinerContador.style.display = "flex";
}
window.dispatchEvent(
new CustomEvent("ponto-trama:ferramenta-alterada", {
detail: { ferramenta }
})
);
}
function init() {
const botoesFerramenta = document.querySelectorAll(".barraLateral .botaoFerramenta");
botoesFerramenta.forEach((botao) => {
botao.addEventListener("click", () => alternarFerramenta(botao));
});
}
return {
init,
alternarFerramenta
};
})();
